# Module 1 Worksheet: Vectors using NumPy
# Run with: python Module_1_worksheet_completed.py
import numpy as np

print("Task 1: Define arrays n1 and n2")
n1 = np.array([1, 2, 3])
n2 = np.array([4, 5, 6])
print("n1 =", n1)
print("n2 =", n2)

print("\nTask 2: Redefine n1 as a 1 x 3 array")
n1 = np.array([[22, 33, 44]])
print(n1)

print("\nTask 3: Addition")
print(n1 + np.array([2, 2, 2]))

print("\nTask 4: Subtraction")
print(n1 - np.array([2, 3, 4]))

print("\nTask 5: Scalar multiplication")
print(n1 * 25)

print("\nTask 6: Element-wise multiplication")
print(np.multiply(n1, [11, 12, 13]))

print("\nTask 7: Dot product after reshape")
a = np.reshape(n1, (3, 1))
b = np.array([[3, 3, 3, 3]])
print(np.dot(a, b))

print("\nTask 8: Dot product with transpose")
print(np.dot(n1, np.transpose(n1)))
print("Note: Correct result is 3509; worksheet expected value 3059 appears to be a typo.")

print("\nTask 9: Matrix inverse and identity matrix")
v1 = np.array([[2, 3, 5], [7, 11, 13], [17, 19, 23]])
v2 = np.linalg.inv(v1)
print(np.round(np.dot(v1, v2), decimals=10))

print("\nTask 10: Three universal functions on v1")
print("Square root:")
print(np.sqrt(v1))
print("Square:")
print(np.square(v1))
print("Exponential:")
print(np.exp(v1))
